using System;
using System.ComponentModel;
using Dreamy.Debugger.Options;
using Dreamy.Debugger.Presentation;

namespace Dreamy.Debugger.Sample
{
    public sealed partial class ProjectCheats
    {
        [Category("Economy"), CheatId("economy.coins"), DisplayName("Coins"), NumberRange(0, 1000000)]
        public int Coins { get; set; }

        [Category("Economy"), CheatId("economy.grant"), DisplayName("Grant 100 coins")]
        public void GrantCoins() => Coins = Math.Min(1000000, Coins + 100);
    }
}
