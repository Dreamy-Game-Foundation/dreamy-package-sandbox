using System.ComponentModel;
using Dreamy.Debugger.Options;

namespace Dreamy.Debugger.Sample
{
    public sealed partial class ProjectCheats
    {
        [Category("Player"), CheatId("player.god-mode"), DisplayName("God mode")]
        public bool GodMode { get; set; }

        [Category("Gameplay"), CheatId("game.speed"), DisplayName("Speed")]
        [Dreamy.Debugger.Presentation.NumberRange(0.1, 5)]
        public float Speed { get; set; } = 1;

        [Category("Gameplay"), CheatId("game.difficulty"), DisplayName("Difficulty")]
        public DemoDifficulty Difficulty { get; set; } = DemoDifficulty.Normal;
    }
}
