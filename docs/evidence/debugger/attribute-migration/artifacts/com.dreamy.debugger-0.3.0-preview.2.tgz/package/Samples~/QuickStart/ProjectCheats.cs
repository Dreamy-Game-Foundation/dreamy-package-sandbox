using System.Collections.Generic;
using Dreamy.Debugger.Options;

namespace Dreamy.Debugger.Sample
{
    public enum DemoDifficulty { Easy, Normal, Hard }

    /// <summary>Editable partial sample; values are in-memory, never real game saves.</summary>
    public sealed partial class ProjectCheats
    {
        public IEnumerable<CheatOption> CreateOptions() => AttributedCheatOptions.From(this, "sample");
    }
}
