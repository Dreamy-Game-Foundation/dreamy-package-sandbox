//#define Debug_CONSOLE_DEBUG

namespace Dreamy.Debugger.Presentation.UI.Tabs
{
    using Dreamy.Debugger.Foundation;
    using UnityEngine.UI;

    public class ProfilerTabController : ComponentBehaviour
    {
        private bool _isDirty;

        [RequiredField] public Toggle PinToggle;

        protected override void Start()
        {
            base.Start();

            PinToggle.onValueChanged.AddListener(PinToggleValueChanged);
            Refresh();
        }

        private void PinToggleValueChanged(bool isOn)
        {
            DreamyDebug.Instance.IsProfilerDocked = isOn;
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            _isDirty = true;
        }

        protected override void Update()
        {
            base.Update();

            if (_isDirty)
            {
                Refresh();
            }
        }

        private void Refresh()
        {
            PinToggle.isOn = DreamyDebug.Instance.IsProfilerDocked;
            _isDirty = false;
        }
    }
}
