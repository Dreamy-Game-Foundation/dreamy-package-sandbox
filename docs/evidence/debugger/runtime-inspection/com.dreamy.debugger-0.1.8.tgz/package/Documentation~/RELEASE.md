# Dreamy Debugger v0.1.8 — Safe cheat value writes

Source release dated 2026-11-20. Package manifest and runtime VersionInfo are 0.1.8. The user authorized committing and pushing the maintained debugger package and sandbox, including the annotated v0.1.8 source tag. Planet's Packages/ directory is intentionally left unchanged; its adapter fix remains game-owned and its package update/rebuilt APK are separate.

The patch contains setter failures at the UI boundary, re-reads authoritative state after accepted/rejected writes, unwraps reflection errors for diagnostics and prevents synthetic bool input/reentrant writes. It retains registry exceptions for direct programmatic use and preserves command availability/access/confirmation checks. No dependency, asmdef, serialized GUID or player-save migration is required.

Before version preparation, exact-source consumer tests passed 16/16 EditMode and 4/4 PlayMode checks; parent receipts are under docs/evidence/debugger/unavailable-toggle-2026-11-20. Those behavior receipts predate the version bump and describe the temporary tested consumer copy, which was removed at the user's request. Version/archive checks for this source preparation are recorded separately under docs/evidence/debugger/release-v0.1.8. Physical Android touch, rebuilt APK, Crashlytics ingestion and fresh Git-install validation are not certified by the Editor tests.

---

# Dreamy Debugger v0.1.7 — Access and UI fixes

Prepared 2026-11-13 as a local package commit. Manifest and runtime VersionInfo are 0.1.7. This preparation does not push, create a tag or publish a release; the README's v0.1.7 Git URL becomes usable once that tag is published. Consumer projects and APKs are updated separately.

This patch defaults new access configuration to three taps, fixes PIN indicators and short-landscape Console search, adds default Until restored hiding alongside 15/30/60-second timers, and removes background seams. Existing serialized consumer tap counts remain unchanged. Flat input surfaces retain authored alpha/raycasts; rounded controls retain their shape. No dependency, assembly or player-save migration is required.

Parent sandbox receipts under `docs/evidence/debugger/ui-fixes-2026-11-13/` record 21 Access EditMode and 29 focused PlayMode passes before surface/version preparation. `docs/evidence/debugger/flat-surfaces-2026-11-13/` records 4 focused PlayMode passes after the surface changes. Game View tests passed; Device Simulator-specific rendering, native mobile input, rebuilt players and exact Git-install validation remain separate gates. Version/archive receipts for this preparation belong to `docs/evidence/debugger/release-v0.1.7/`.

---

# Dreamy Debugger v0.1.6 — Screenshot workflow fixes

Source release dated 2026-11-12. Manifest and runtime VersionInfo are 0.1.6; Git consumers pin the annotated `v0.1.6` tag. Consumer projects and APKs are updated separately; no automatic consumer update is included.

Screenshot mode now arms corner capture immediately, independently of Hide UI. Capture retains Keep/All/Selected presets; manual Hide has All/Selected only. Gameplay masking changes alpha only. Includes fast tap events, capture acknowledgment/saved feedback, mobile native path correction, storage-read concurrency, safe-area bounds and the illustrated offline HTML guide. See [README](../README.md), [changelog](../CHANGELOG.md) and [migration](MIGRATION.md).

Before version/documentation preparation, parent sandbox `docs/evidence/debugger/mode-hide-capture-split/verification.json` records 23 focused PlayMode and 2 prefab/catalog EditMode passes at its recorded source fingerprint. Version/archive checks for this preparation belong to `docs/evidence/debugger/release-v0.1.6/`; do not treat earlier receipts as proof of a later archive or Git revision.

No Android/LDPlayer APK rebuild/install, native device validation, fresh committed Git-consumer import or performance profiling is certified. Dependencies and existing GUIDs remain unchanged.

---

# Dreamy Debugger v0.1.5 — Screenshot Mode

Release source dated 2026-11-12. Manifest and runtime VersionInfo are 0.1.5; Git consumers pin the annotated `v0.1.5` tag. See [changelog](../CHANGELOG.md) and [Screenshot workflow](../README.md#screenshot--tab-riêng-cho-ảnh-gameplay).

Includes the dedicated camera tab, Canvas UI hiding/restoration, native PNG capture, preview/review, Editor window, Android 10+ Gallery/share and local storage count/cleanup. Existing serialized references are preserved; no save migration is required.

Behavior receipts before this version/documentation update: parent project `docs/evidence/debugger/screenshot-storage/verification.json` records 19 focused PlayMode and 2 prefab/catalog EditMode passes on Unity 6000.4.12f1. Those receipts certify their recorded source fingerprint, not a later version or archive. Archive/version checks for this preparation are recorded separately under `docs/evidence/debugger/release-v0.1.5/` in the parent project.

Fresh committed Git-install parity/compile, Android device/emulator gestures and native export, iOS native adapters, IL2CPP stripping and frame-time/RAM/thermal profiling remain separate gates. No store-resolution presets are included.

---

# Dreamy Debugger v0.1.4 — Package cleanup

2026-11-10. Documentation and package-content patch; no runtime behavior or dependency changes. See [changelog](../CHANGELOG.md) and [setup guide](../README.md).

Validation: local documentation links, unchanged screenshots, manifest/runtime version consistency and package archive verification. No fresh Unity compilation, Git-import compilation or device tests were run for this patch. Earlier receipts below apply only to their original source/artifacts.

---

# Dreamy Debugger v0.1.3 — Material Compact

Prepared 2026-11-09 for private internal distribution. Package manifest and runtime VersionInfo are 0.1.3; author remains Dreamy Game Studio. No tag, upload, push or release publication is performed by this preparation.

Material Compact integrates real Barlow/JetBrains Mono fonts and tiny Material PNG sprites, an alpha Dreamy logo extracted from supplied artwork, compact resource cards and lazy pinned-category chips, HUD cycle/close controls, titleless centered PIN with independent Cancel/Delete, closeable log dock and revised Editor Settings. The sidebar fix allocates its safe-area inset in the rail width and keeps icons/header/tab rows/content aligned through viewport changes. Dependencies, cheat identity and existing meta GUIDs remain compatible. See [README](../README.md), [migration](MIGRATION.md) and [asset provenance](MATERIAL_UI.md).

Current verification receipts belong to parent `docs/evidence/debugger/release-v0.1.3/`. Source/working-tree tests, archive content validation and exact artifact hashes must be recorded there for this candidate. Earlier Material Compact Git parity at commit cef4acb and earlier version receipts remain historical; they do not certify a later 0.1.3 commit or tag. A final committed release still needs exact Git-install parity/compile before distribution through that method.

Physical Android/iOS touch, notches/IME, native Editor-window visual capture, mobile texture-quality/GPU residency, IL2CPP stripping, capture frame-time/GC/thermal and production relay delivery remain separate open gates. The synthetic viewport fixtures and importer ASTC presets do not certify these. Preserve vendor-derived distribution restrictions and third-party notices. The current candidate is not certified for production/device performance.

---

# Historical v0.1.2 — landscape layout

Responsive numeric PIN/passphrase layout, invisible configurable tap target, compact full-viewport HUD without safe-area constraints, short-screen navigation and Editor/Simulator safe-area updates. Root prefab GUIDs and option IDs remain unchanged; imported samples do not need replacement for these runtime changes. User HUD mode/free position/scale preferences remain local; reset preferences only when intentionally testing clean defaults.

Fresh rendered viewport screenshots, actual control-bounds/raycast/submit tests, source/installed Git parity and complete package-test receipts belong to parent `docs/evidence/debugger/landscape-layout/`. The fixture covers 852×393, 640×300, 393×852 and rotation. These are actual Unity render-texture fixtures, not device screenshots or native touch/keyboard acceptance. Existing mobile/device/production limitations below remain open.

---

# Dreamy Debugger v0.1.1 — Git import hotfix

0.1.0 Git commit `5912da131b70d7574f3e25bd18f7c046ce34024a` reproduces CS0234/CS0246 in a new Unity 6000.4.12f1 project. Its broad `.gitignore` `data/` rule causes UPM Git packaging to omit 16 tracked files in `Controls/Data`: eight scripts and their existing metas. The tested npm tarball includes those files, so previous tarball/source acceptance did not cover the failing installation method.

0.1.1 limits the rule to `/Tools~/relay/data/`, preserves all asmdefs/GUIDs and adds `Tools~/verify_git_install.py`. Fresh Git-install source parity and Unity compile must pass before calling this fix accepted. Exact before/after source commits, checks and compiler receipts are in parent `docs/evidence/debugger/git-import-hotfix/`. Do not count the historical v0.1.0 archive test as proof of Git import.

Maintainer: install the exact Git commit in a new consumer, then run `python3 Tools~/verify_git_install.py <source-repo> <resolved-package-dir>`. Require byte parity for shipped tracked files and compile/import the sample. Retain archive verification, package tests and all device/privacy/deployment limits below. No assembly reference workaround or generated PackageCache edit is part of the fix.

---

# Historical v0.1.0 release preparation


Prepared 2026-11-06 for **private internal distribution**. Package manifest and `DreamyDebug.Version` are `0.1.0`; author is Dreamy Game Studio. This prepares a release artifact and documentation; it does not create a tag, push, upload or publish a release.

## Version policy

The requested `0.1.0` starts a new numbering line from the development source previously labelled `0.3.0-preview.6`. Existing repository tags `v0.2.0-preview.*` are retained. This is numerically lower under semver, so consumers must explicitly pin the intended commit/archive or the future `v0.1.0` tag; a version-range resolver will not treat it as an upgrade from `0.2.x`/`0.3.x`. No GUID, namespace, package identity or cheat ID is reset.

## Contents

- Automatic startup or explicit Manual initialization; independently usable package with Unity-only required dependencies.
- Configurable tap/PIN/passphrase access; Console, attributed partial cheats, owned registry/confirmation/cards, Performance/HUD and System views.
- Quick Start import-to-Play, editable partial files and complete game-owned integration guide.
- Optional local reports/screenshots and Telegram relay. Email is removed; no runtime package-author report tab or embedded bot credentials.
- Runtime presentation preferences, category pins, full retained stack details, Geist/flat interface and translucent draggable HUD.

Read [README](../README.md) for setup and APIs, [migration](MIGRATION.md) before updating an edited sample, and the retained vendor documentation for upstream restrictions.

## Release verification

Fresh source/archive receipts, exact artifact hash and package commit are recorded externally in the parent sandbox at `docs/evidence/debugger/release-v0.1.0/`. Artifacts are kept outside the package to avoid recursive/self-referential hashes. The scope is Unity 6000.4.12f1 / Linux and Test Framework 1.6.0; declared minimum Unity 6000.0 is not a claim that all Unity 6 versions were tested.

Acceptance target: 92 EditMode + 64 PlayMode tests including imported Quick Start, compilation of the complete README game host/partial examples, archive metadata/content validation and 20 offline relay/setup tests. The external checkpoint records the actual fresh result and artifact hash.

Earlier preview build/device/visual receipts remain historical. They do not certify v0.1.0. Consult the fresh checkpoint for actual counts and any unavailable check; preparation alone is not a passed gate.

## Checks before distribution

1. Verify package.json, runtime version, README and changelog agree; retain every existing meta GUID and third-party notice.
2. Pack the allowlisted files and run `python3 Tools~/verify_package.py <archive.tgz>`; exclude local relay DB/cache/logs/secrets and repository internals.
3. Install that exact archive in an isolated Unity consumer, import its Quick Start and run EditMode/PlayMode tests. Compile the complete README host/partial examples against it.
4. For the intended game/platform, run Development and ordinary release smoke builds and verify the correct startup policy. For IL2CPP, preserve the game's own reflected containers and test on device.
5. Before enabling automatic screenshots/remote uploads, validate the game's sensitive-screen policy, network/relay configuration, retention and applicable disclosure/consent flow.
6. After reviewing the artifact/receipts, a maintainer can create the private release/tag for the verified commit. Keep existing tags unchanged and record rollback commit/config/sample versions.

## Remaining device/deployment gates

- Mobile touch, notches/DPI/rotation/IME, GPU readback and weak-device p95/p99/GC/thermal/battery under capture/send load.
- On-device IL2CPP/stripping and native fault/ANR/OOM/OS-kill acceptance for the actual game; no screenshot is guaranteed after process death.
- iOS/Xcode/device validation and production HTTPS relay deployment/destination delivery.
- Production privacy/masking/withdrawal/purge behavior belongs to the host; `SensitiveScreen` is a capture veto, not a full masking or consent subsystem.

No lag-free, universal Unity/platform support or production crash-certification claim accompanies this internal release. Vendor-derived content keeps its original restrictions; public redistribution is not granted by the version change.
