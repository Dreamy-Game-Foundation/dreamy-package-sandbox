# Current checkpoint — v0.1.8

2026-11-20. Setter exception containment, authoritative value readback and bool input-event isolation completed. Manifest/runtime/current documentation aligned at 0.1.8; the user authorized commit/push of package and sandbox plus the source tag. Planet Packages/ remains unchanged pending its owner-managed update. Source-bound behavior receipts and distinct release/version/archive checks are described in [release scope](RELEASE.md). Earlier checkpoints are historical.

---

# Current checkpoint — v0.1.7

2026-11-13. Local package commit for three-tap defaults, PIN/search layout fixes, indefinite Screenshot Hide UI and seamless flat/rounded surfaces. Manifest/runtime version and current documentation are aligned at 0.1.7. No tag, push, publication or consumer build is included. Source-bound behavior receipts and separate version/archive checks are described in [release scope](RELEASE.md). Earlier checkpoints below are historical.

---

# Current checkpoint — v0.1.6

2026-11-12. Sandbox-only source release for independent Screenshot mode, capture presets and manual Hide UI. Manifest/runtime version 0.1.6; README, illustrated HTML guide, changelog and migration are aligned. Source distribution uses annotated tag `v0.1.6`; consumer-project updates and APK builds are separate. See [release scope](RELEASE.md) for source-bound verification limits. Earlier checkpoints below are historical.

---

# Current checkpoint — v0.1.5

2026-11-12. Screenshot workflow and local storage management completed in the local package. Manifest/runtime version 0.1.5; documentation and archive checks recorded separately from the preceding behavior receipts. Source release uses annotated tag `v0.1.5`. See [release scope](RELEASE.md) for exact validation limits. Earlier checkpoints below are historical.

---

# Current checkpoint — v0.1.4

2026-11-10. Package cleanup and expanded setup/cheat authoring documentation completed. Manifest/runtime version 0.1.4; existing screenshot assets retained. See [release scope](RELEASE.md) for validation limits. Earlier checkpoints below are historical.

---

# Current checkpoint — v0.1.3 release preparation

2026-11-09. Material Compact plus inset-aware sidebar alignment, manifest/runtime version and import/sample documentation updated to 0.1.3. Candidate receipts and remaining acceptance limits: parent `docs/evidence/debugger/release-v0.1.3/` and [RELEASE.md](RELEASE.md). No new tag or publication. Keep earlier receipts tied to their exact source; native Editor visual/device/production gates remain open.

---

# Historical checkpoint — v0.1.2 landscape layout

Full-viewport compact HUD, invisible tap entry, responsive centered PIN/passphrase and short-screen navigation. Fresh rendered viewport and package/Git acceptance receipts belong to parent docs/evidence/debugger/landscape-layout. Do not use older preview screenshots as visual proof for this change. No device/native keyboard acceptance is implied.

---

# Current checkpoint — v0.1.1 Git packaging fix

Affected v0.1.0 Git import reproduced; packaging ignore scope corrected without asmdef/GUID changes. Before/after Git-install parity and fresh Unity compiler/test receipts belong to parent `docs/evidence/debugger/git-import-hotfix/`. This supersedes the v0.1.0 Git installation claim; prior archive receipts remain valid only for their exact archive. See RELEASE.md.

---

# Current checkpoint — v0.1.0

2026-11-06. Release preparation consolidates the preview source into the requested internal `0.1.x` numbering line. See [release status](RELEASE.md), [migration](MIGRATION.md), [changelog](../CHANGELOG.md) and [setup/API guide](../README.md).

Implementation: automatic/manual startup, configurable access, attributed partial cheat authoring and owned registration, cards/confirmation, console full retained details, default-off draggable HUD/local presentation preferences, styled runtime panels/dialogs, optional screenshots/outbox and Telegram relay. Quick Start now auto-registers after import in debug builds; game wallet/save bindings remain project-owned.

Matching v0.1.0 receipt scope is recorded in the parent sandbox `docs/evidence/debugger/release-v0.1.0/`. Previous phase/preview evidence is historical and remains in version control. Implementation is not equivalent to mobile/device, crash, performance or privacy acceptance; open gates are listed in RELEASE.md and PLATFORM_SUPPORT.md.

No tag, push, publication, report delivery or user-scene crash is implied. Private upstream licensing restrictions remain in effect. This checkpoint supersedes the older preview status headings; use git history when inspecting those checkpoints.
