using System;
using System.Collections.Generic;

namespace Dreamy.Debugger.Presentation
{
    /// <summary>
    /// You can implement this interface to create a dynamic "options container".
    /// Add the container to Dreamy.Debugger.Presentation via the DreamyDebug API.
    /// </summary>
    /// <remarks>
    /// When the container is added via the API, the initial set of options will be fetched via <see cref="GetOptions"/>.
    /// Options that are added or removed after this point must fire the <see cref="OptionAdded"/> and <see cref="OptionRemoved"/> events in order
    /// for those options to be added/removed from the debug panel.
    /// If you do not intend to fire any events (i.e. this is a static container) then <see cref="IsDynamic"/> should return false.
    /// </remarks>
    public interface IOptionContainer
    {
        /// <summary>
        /// Get the initial set of options contained in this object.
        /// </summary>
        IEnumerable<OptionDefinition> GetOptions();

        /// <summary>
        /// Will the options collection be changed via events?
        /// If true, changes to the option set can be provided via the events <see cref="OptionAdded"/> and <see cref="OptionRemoved"/>.
        /// If false, the events will be ignored.
        /// </summary>
        bool IsDynamic { get; }

        event Action<OptionDefinition> OptionAdded;
        event Action<OptionDefinition> OptionRemoved;
    }

    public interface IBatchedOptionContainer
    {
        bool IsUpdating { get; }
        event Action BatchCompleted;
    }

    public sealed class DynamicOptionContainer : IOptionContainer, IBatchedOptionContainer
    {
        private int updateDepth;
        private bool changed;
        public bool IsUpdating => updateDepth > 0;
        public event Action BatchCompleted;
        public IDisposable BeginUpdate() { updateDepth++; return new Batch(this); }
        private void EndUpdate() {
            if(--updateDepth==0 && changed){changed=false;BatchCompleted?.Invoke();}
        }
        private sealed class Batch : IDisposable {
            private DynamicOptionContainer owner;
            public Batch(DynamicOptionContainer owner){this.owner=owner;}
            public void Dispose(){var previous=owner;owner=null;if(previous!=null)previous.EndUpdate();}
        }

        public IList<OptionDefinition> Options
        {
            get { return _optionsReadOnly; }
        }

        private readonly List<OptionDefinition> _options = new List<OptionDefinition>();
        private readonly IList<OptionDefinition> _optionsReadOnly;

        public DynamicOptionContainer()
        {
            _optionsReadOnly = _options.AsReadOnly();
        }

        public void AddOption(OptionDefinition option)
        {
            _options.Add(option);
            if(IsUpdating)changed=true;

            if (OptionAdded != null)
            {
                OptionAdded(option);
            }
        }

        public bool RemoveOption(OptionDefinition option)
        {
            if (_options.Remove(option))
            {
                if(IsUpdating)changed=true;
                if (OptionRemoved != null)
                {
                    OptionRemoved(option);
                }

                return true;
            }

            return false;
        }
        
        IEnumerable<OptionDefinition> IOptionContainer.GetOptions()
        {
            return _options;
        }

        public bool IsDynamic
        {
            get { return true; }
        }

        public event Action<OptionDefinition> OptionAdded;
        public event Action<OptionDefinition> OptionRemoved;
    }

}