//#define Debug_CONSOLE_DEBUG

using System.Collections;

namespace Dreamy.Debugger.Presentation.UI.Tabs
{
    using System;
    using Controls;
    using Internal;
    using Services;
    using Dreamy.Debugger.Foundation;
    using UnityEngine;
    using UnityEngine.UI;

    public class ConsoleTabController : ComponentBehaviour
    {
        private ConsoleDetailPager detailPager;
        public ConsoleDetailPager DetailPager => detailPager;

        private Canvas _consoleCanvas;
        private bool _isDirty;

        private static bool _hasWarnedAboutLogHandler;
        private static bool _hasWarnedAboutLoggingDisabled;

        [Import]
        public IConsoleFilterState FilterState;

        [RequiredField]
        public ConsoleLogControl ConsoleLogControl;

        [RequiredField]
        public Toggle PinToggle;
        //public bool IsListening = true;

        [RequiredField]
        public ScrollRect StackTraceScrollRect;
        [RequiredField]
        public Text StackTraceText;
        [RequiredField]
        public Toggle ToggleErrors;
        [RequiredField]
        public Text ToggleErrorsText;
        [RequiredField]
        public Toggle ToggleInfo;
        [RequiredField]
        public Text ToggleInfoText;
        [RequiredField]
        public Toggle ToggleWarnings;
        [RequiredField]
        public Text ToggleWarningsText;

        [RequiredField]
        public GameObject CopyToClipboardContainer;

        [RequiredField]
        public GameObject CopyToClipboardButton;

        [RequiredField]
        public GameObject CopyToClipboardMessage;

        [RequiredField]
        public CanvasGroup CopyToClipboardMessageCanvasGroup;

        [RequiredField]
        public GameObject LoggingIsDisabledCanvasGroup;

        [RequiredField]
        public GameObject LogHandlerHasBeenOverridenGroup;

        [RequiredField]
        public Toggle FilterToggle;
        [RequiredField]
        public InputField FilterField;
        [RequiredField]
        public GameObject FilterBarContainer;

        public Toggle CollapseToggle;
        public Button DetailBack;
        public RectTransform DetailPane, ListPane;
        private static ConsoleTabController active;
        private float lastWidth;
        public bool IsShowingDetails => _selectedItem!=null;
        public void CloseDetails(){ConsoleLogControl.SelectEntry(null);PopulateStackTraceArea(null);}
        public static bool DismissDetails(){if(active==null || !active.isActiveAndEnabled || !active.IsShowingDetails || ((RectTransform)active.transform).rect.width>=600)return false;active.CloseDetails();return true;}
        private void LayoutDetails(){
            if(DetailPane==null || ListPane==null)return;
            lastWidth=((RectTransform)transform).rect.width;var narrow=lastWidth<600;var show=_selectedItem!=null;
            var toolbar=transform.Find("Layout/Console toolbar");if(toolbar!=null)toolbar.gameObject.SetActive(!narrow || !show);
            DetailPane.gameObject.SetActive(show);ListPane.gameObject.SetActive(!show || !narrow);
            if(DetailBack!=null)DetailBack.gameObject.SetActive(narrow && show);
            var layout=DetailPane.GetComponent<LayoutElement>();layout.preferredHeight=narrow?-1:200;layout.flexibleHeight=narrow?1:0;
        }
        private ConsoleEntry _selectedItem;

        private Coroutine _fadeButtonCoroutine;

        protected override void Start()
        {
            if (FilterBarContainer != null)
            {
                var searchLayout = FilterBarContainer.GetComponent<LayoutElement>() ?? FilterBarContainer.AddComponent<LayoutElement>();
                searchLayout.minHeight = searchLayout.preferredHeight = 44;
                searchLayout.flexibleHeight = 0;
            }
            if (FilterField != null)
            {
                if (FilterField.GetComponent<RectMask2D>() == null) FilterField.gameObject.AddComponent<RectMask2D>();
                if (FilterField.placeholder is Text hint)
                {
                    hint.horizontalOverflow = HorizontalWrapMode.Overflow;
                    hint.verticalOverflow = VerticalWrapMode.Truncate;
                    hint.resizeTextForBestFit = true;
                    hint.resizeTextMinSize = 10; hint.resizeTextMaxSize = 14;
                }
            }

            base.Start();

            PreferenceBridge.Restored+=RestorePreferences;
            _consoleCanvas = GetComponent<Canvas>();
            if(DetailBack!=null)DetailBack.onClick.AddListener(CloseDetails);
            if(CollapseToggle!=null && Service.Console is Dreamy.Debugger.Presentation.Services.Implementation.StandardConsoleService standard){CollapseToggle.SetIsOnWithoutNotify(standard.CollapseEnabled);CollapseToggle.onValueChanged.AddListener(value=>standard.CollapseEnabled=value);}
            
            ToggleErrors.isOn = FilterState.GetConsoleFilterState(LogType.Error);
            ToggleWarnings.isOn = FilterState.GetConsoleFilterState(LogType.Warning);
            ToggleInfo.isOn = FilterState.GetConsoleFilterState(LogType.Log);
            
            ToggleErrors.onValueChanged.AddListener(isOn =>
            {
                FilterState.SetConsoleFilterState(LogType.Error, isOn);
                _isDirty = true;
            });

            ToggleWarnings.onValueChanged.AddListener(isOn =>
            {
                FilterState.SetConsoleFilterState(LogType.Warning, isOn);
                _isDirty = true;
            });

            ToggleInfo.onValueChanged.AddListener(isOn =>
            {
                FilterState.SetConsoleFilterState(LogType.Log, isOn);
                _isDirty = true;
            });

            PinToggle.onValueChanged.AddListener(PinToggleValueChanged);

            FilterToggle.onValueChanged.AddListener(FilterToggleValueChanged);
            FilterBarContainer.SetActive(FilterToggle.isOn);

#if UNITY_5_3_OR_NEWER
            FilterField.onValueChanged.AddListener(FilterValueChanged);
#else
            FilterField.onValueChange.AddListener(FilterValueChanged);
#endif

            ConsoleLogControl.SelectedItemChanged = ConsoleLogSelectedItemChanged;

            Service.Console.Updated += ConsoleOnUpdated;
            Service.Panel.VisibilityChanged += PanelOnVisibilityChanged;
            FilterState.FilterStateChange += OnFilterStateChange;

            detailPager = new ConsoleDetailPager(StackTraceText, StackTraceScrollRect);
            PopulateStackTraceArea(null);

            Refresh();
        }

        private void OnFilterStateChange(LogType logtype, bool newstate)
        {
            switch (logtype)
            {
                case LogType.Error:
                    ToggleErrors.isOn = newstate;
                    break;
                case LogType.Warning:
                    ToggleWarnings.isOn = newstate;
                    break;
                case LogType.Log:
                    ToggleInfo.isOn = newstate;
                    break;
            }
        }
        
        private void FilterToggleValueChanged(bool isOn)
        {
            if (isOn)
            {
                FilterBarContainer.SetActive(true);
                ConsoleLogControl.Filter = FilterField.text;
            }
            else
            {
                ConsoleLogControl.Filter = null;
                FilterBarContainer.SetActive(false);
            }
        }
        private void FilterValueChanged(string filterText)
        {
            if (FilterToggle.isOn && !string.IsNullOrEmpty(filterText) && filterText.Trim().Length != 0)
            {
                ConsoleLogControl.Filter = filterText;
            }
            else
            {
                ConsoleLogControl.Filter = null;
            }
        }

        private void PanelOnVisibilityChanged(IDebugPanelService debugPanelService, bool b)
        {
            if (_consoleCanvas == null)
            {
                return;
            }

            if (b)
            {
                _consoleCanvas.enabled = true;
            }
            else
            {
                _consoleCanvas.enabled = false;
                StopAnimations();
            }
        }

        private void PinToggleValueChanged(bool isOn)
        {
            Service.DockConsole.IsVisible = isOn;
        }

        private void RestorePreferences(){if(CollapseToggle!=null && Service.Console is Dreamy.Debugger.Presentation.Services.Implementation.StandardConsoleService console)CollapseToggle.SetIsOnWithoutNotify(console.CollapseEnabled);}
        protected override void OnDestroy()
        {
            PreferenceBridge.Restored-=RestorePreferences;
            StopAnimations();

            if (Service.Console != null)
            {
                Service.Console.Updated -= ConsoleOnUpdated;
            }

            if (FilterState != null) FilterState.FilterStateChange -= OnFilterStateChange;

            
            base.OnDestroy();
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            active=this;
            _isDirty = true;
        }

        protected override void OnDisable()
        {
            if(active==this)active=null;
            base.OnDisable();
            StopAnimations();
        }

        private void ConsoleLogSelectedItemChanged(object item)
        {
            var log = item as ConsoleEntry;
            PopulateStackTraceArea(log);
        }

        protected override void Update()
        {
            base.Update();

            if(!Mathf.Approximately(lastWidth,((RectTransform)transform).rect.width))LayoutDetails();
            if (_isDirty)
            {
                Refresh();
            }
        }

        private void PopulateStackTraceArea(ConsoleEntry entry)
        {
            if (entry == null)
            {
                SetCopyToClipboardButtonState(CopyToClipboardStates.Hidden);
                detailPager.SetContent("");
            }
            else
            {
                if (DreamyDebug.CopyConsoleItemCallback != null)
                {
                    SetCopyToClipboardButtonState(CopyToClipboardStates.Visible);
                }

                var text = entry.Message + Environment.NewLine +
                           (!string.IsNullOrEmpty(entry.StackTrace)
                               ? entry.StackTrace
                               : PanelStrings.Current.Console_NoStackTrace);

                detailPager.SetContent(text);
            }

            StackTraceScrollRect.normalizedPosition = new Vector2(0, 1);
            _selectedItem = entry;
            LayoutDetails();
        }

        public void CopyToClipboard()
        {
            if (_selectedItem != null)
            {
                SetCopyToClipboardButtonState(CopyToClipboardStates.Activated);
                if (DreamyDebug.CopyConsoleItemCallback != null)
                {
                    DreamyDebug.CopyConsoleItemCallback(_selectedItem);
                }
                else
                {
                    Debug.LogError("[DreamyDebugger] Copy to clipboard is not available.");
                }
            }
        }

        public enum CopyToClipboardStates
        {
            Hidden,
            Visible,
            Activated
        }

        void SetCopyToClipboardButtonState(CopyToClipboardStates state)
        {
            StopAnimations();

            switch (state)
            {
                case CopyToClipboardStates.Hidden:
                    CopyToClipboardContainer.SetActive(false);
                    CopyToClipboardButton.SetActive(false);
                    CopyToClipboardMessage.SetActive(false);
                    break;
                case CopyToClipboardStates.Visible:
                    CopyToClipboardContainer.SetActive(true);
                    CopyToClipboardButton.SetActive(true);
                    CopyToClipboardMessage.SetActive(false);
                    break;
                case CopyToClipboardStates.Activated:
                    CopyToClipboardMessageCanvasGroup.alpha = 1;
                    CopyToClipboardContainer.SetActive(true);
                    CopyToClipboardButton.SetActive(false);
                    CopyToClipboardMessage.SetActive(true);

                    _fadeButtonCoroutine = StartCoroutine(FadeCopyButton());
                    break;
                default:
                    throw new ArgumentOutOfRangeException("state", state, null);
            }
        }

        IEnumerator FadeCopyButton()
        {
            yield return new WaitForSecondsRealtime(2f);

            float startTime = Time.realtimeSinceStartup;
            float endTime = Time.realtimeSinceStartup + 1f;

            while (Time.realtimeSinceStartup < endTime)
            {
                float currentAlpha = Mathf.InverseLerp(endTime, startTime, Time.realtimeSinceStartup);
                CopyToClipboardMessageCanvasGroup.alpha = currentAlpha;
                yield return new WaitForEndOfFrame();
            }

            CopyToClipboardMessageCanvasGroup.alpha = 0;
            _fadeButtonCoroutine = null;
        }

        void StopAnimations()
        {
            if (_fadeButtonCoroutine != null)
            {
                StopCoroutine(_fadeButtonCoroutine);
                _fadeButtonCoroutine = null;
                CopyToClipboardMessageCanvasGroup.alpha = 0;
            }
        }

        private void Refresh()
        {
            // Update total counts labels
            ToggleInfoText.text = "Info " + PresentationUtility.GetNumberString(Service.Console.InfoCount, 999, "999+");
            ToggleWarningsText.text = "Warn " + PresentationUtility.GetNumberString(Service.Console.WarningCount, 999, "999+");
            ToggleErrorsText.text = "Error " + PresentationUtility.GetNumberString(Service.Console.ErrorCount, 999, "999+");

            ConsoleLogControl.ShowErrors = ToggleErrors.isOn;
            ConsoleLogControl.ShowWarnings = ToggleWarnings.isOn;
            ConsoleLogControl.ShowInfo = ToggleInfo.isOn;

            PinToggle.isOn = Service.DockConsole.IsVisible;

            _isDirty = false;

            if (!_hasWarnedAboutLogHandler && Service.Console.LogHandlerIsOverriden)
            {
                LogHandlerHasBeenOverridenGroup.SetActive(true);
                _hasWarnedAboutLogHandler = true;
            }

            if (!_hasWarnedAboutLoggingDisabled && !Service.Console.LoggingEnabled)
            {
                LoggingIsDisabledCanvasGroup.SetActive(true);
            }
        }

        private void ConsoleOnUpdated(IConsoleService console)
        {
            _isDirty = true;
        }

        public void Clear()
        {
            Service.Console.Clear();
            _isDirty = true;
        }

        public void LogHandlerHasBeenOverridenOkayButtonPress()
        {
            _hasWarnedAboutLogHandler = true;
            LogHandlerHasBeenOverridenGroup.SetActive(false);
        }

        public void LoggingDisableCloseAndIgnorePressed()
        {
            LoggingIsDisabledCanvasGroup.SetActive(false);
            _hasWarnedAboutLoggingDisabled = true;
        }       
        
        public void LoggingDisableReenablePressed()
        {
            Service.Console.LoggingEnabled = true;
            LoggingIsDisabledCanvasGroup.SetActive(false);

            Debug.Log("[DreamyDebugger] Re-enabled logging.");
        }
    }
}
