using System.Linq;
using System.Collections;
using System.Diagnostics;

namespace Dreamy.Debugger.Presentation.UI.Tabs
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Controls;
    using Controls.Data;
    using Internal;
    using Other;
    using Services;
    using Dreamy.Debugger.Foundation;
    using UnityEngine;
using Debug=UnityEngine.Debug;
    using UnityEngine.UI;

    public class OptionsTabController : ComponentBehaviour
    {
        private class CategoryInstance
        {
            public CategoryGroup CategoryGroup { get; private set; }
            public string Name;
            public readonly List<GameObject> Roots=new List<GameObject>();
            public readonly List<OptionsControlBase> Options = new List<OptionsControlBase>();

            public CategoryInstance(CategoryGroup group)
            {
                CategoryGroup = group;
            }
        }

        private readonly List<OptionsControlBase> _controls = new List<OptionsControlBase>();
        private readonly List<CategoryInstance> _categories = new List<CategoryInstance>();

        private readonly Dictionary<OptionDefinition, OptionsControlBase> _options =
            new Dictionary<OptionDefinition, OptionsControlBase>();

        public InputField SearchField;
        public Dropdown CategoryFilter;
        public Toggle PinnedOnly;
        public Text ResultCount;
        public OptionCard TaskCardPrefab;
        public int VisibleOptionCount { get; private set; }
        private readonly Dictionary<string,bool> collapsed = new Dictionary<string,bool>(StringComparer.Ordinal);
        private readonly Dictionary<OptionsControlBase,GameObject> roots = new Dictionary<OptionsControlBase,GameObject>();
        private readonly Dictionary<GameObject,bool> shownRoots=new Dictionary<GameObject,bool>();
        private readonly Dictionary<OptionsControlBase,string> searchIndex=new Dictionary<OptionsControlBase,string>();
        private readonly List<OptionCard> cards = new List<OptionCard>();
        private string query = "", categoryFilter = "";
        private bool pinnedOnly;
        public void SetSearch(string value) { query = value ?? ""; ApplyFilters(); }
        public void SetCategory(string value) { categoryFilter = value ?? ""; ApplyFilters(); }
        public void SetPinnedOnly(bool value) { pinnedOnly = value; ApplyFilters(); }
        public void ToggleCategory(string name) { collapsed[name] = !IsCollapsed(name); ApplyFilters(); }
        public bool IsCollapsed(string name) { return collapsed.TryGetValue(name, out var value) ? value : name == "Debugger"; }
        private void ApplyFilters()
        {
            VisibleOptionCount = 0;
            foreach (var category in _categories) {
                var forceExpanded=query.Length>0 || pinnedOnly || categoryFilter.Length>0;
                var any = false;
                foreach(var root in category.Roots)shownRoots[root]=false;
                foreach (var control in category.Options) {
                    var option = control.Option;
                    var terms=searchIndex[control];
                    var match = (categoryFilter.Length == 0 || category.Name == categoryFilter) &&
                        (!pinnedOnly || Service.PinnedUI.HasPinned(option)) && terms.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0;
                    any |= match; if (match) VisibleOptionCount++;
                    var show = match && (forceExpanded || !IsCollapsed(category.Name));
                    control.gameObject.SetActive(show);
                    if (show) shownRoots[roots[control]]=true;
                }
                foreach (var root in category.Roots)
                    if (root.GetComponent<OptionCard>() != null) root.SetActive(shownRoots[root]);
                category.CategoryGroup.gameObject.SetActive(any);
                if (category.CategoryGroup.CollapseIndicator != null) category.CategoryGroup.CollapseIndicator.text = forceExpanded?"":IsCollapsed(category.Name) ? "+" : "-";
                if(category.CategoryGroup.CollapseButton!=null)category.CategoryGroup.CollapseButton.interactable=!forceExpanded;
            }
            if (ResultCount != null) ResultCount.text = VisibleOptionCount + " options";
            NoOptionsNotice.SetActive(VisibleOptionCount == 0);
        }
        private Coroutine population;
        private bool started, pendingPopulation;
        public bool IsBuilding { get; private set; }
        private bool slicePopulation;
        private bool _queueRefresh;
        private bool _selectionModeEnabled;
        private Canvas _optionCanvas;

        [RequiredField] public ActionControl ActionControlPrefab;

        [RequiredField] public CategoryGroup CategoryGroupPrefab;

        [RequiredField] public RectTransform ContentContainer;

        [RequiredField] public GameObject NoOptionsNotice;

        [RequiredField] public Toggle PinButton;

        [RequiredField] public GameObject PinPromptSpacer;

        [RequiredField] public GameObject PinPromptText;


        protected override void Start()
        {
            base.Start();

            PinButton.onValueChanged.AddListener(SetSelectionModeEnabled);

            PinPromptText.SetActive(false);
            PinPromptSpacer.SetActive(false);

            if (SearchField != null) SearchField.onValueChanged.AddListener(SetSearch);
            if (PinnedOnly != null) PinnedOnly.onValueChanged.AddListener(SetPinnedOnly);
            if (CategoryFilter != null) CategoryFilter.onValueChanged.AddListener(index => SetCategory(index == 0 ? "" : CategoryFilter.options[index].text));
            started=true;
            Populate();

            _optionCanvas = GetComponent<Canvas>();

            Service.Options.OptionsUpdated += OnOptionsUpdated;
            Service.PinnedUI.OptionPinStateChanged += OnOptionPinnedStateChanged;
        }

        protected override void OnDestroy()
        {
            if (Service.Options != null)
            {
                Service.Options.OptionsUpdated -= OnOptionsUpdated;
            }

            if (Service.PinnedUI != null)
            {
                Service.PinnedUI.OptionPinStateChanged -= OnOptionPinnedStateChanged;
            }

            base.OnDestroy();
        }

        private void OnOptionPinnedStateChanged(OptionDefinition optionDefinition, bool isPinned)
        {
            if (_options.ContainsKey(optionDefinition))
            {
                _options[optionDefinition].IsSelected = isPinned;
                ApplyFilters();
            }
        }

        private void OnOptionsUpdated(object sender, EventArgs eventArgs)
        {
            if(isActiveAndEnabled)Populate();else{pendingPopulation=true;Clear();}
        }

        protected override void OnEnable()
        {
            base.OnEnable();

            Service.Panel.VisibilityChanged += PanelOnVisibilityChanged;
            if(started && pendingPopulation)Populate();
        }

        protected override void OnDisable()
        {
            if(IsBuilding){if(population!=null)StopCoroutine(population);IsBuilding=false;pendingPopulation=true;}
            // Always end pinning mode when tabbing away
            SetSelectionModeEnabled(false);

            if (Service.Panel != null)
            {
                Service.Panel.VisibilityChanged -= PanelOnVisibilityChanged;
            }

            base.OnDisable();
        }

        protected override void Update()
        {
            base.Update();

            if (_queueRefresh)
            {
                _queueRefresh = false;
                Refresh();
            }
        }

        private void PanelOnVisibilityChanged(IDebugPanelService debugPanelService, bool b)
        {
            // Always end pinning mode when panel is closed
            if (!b)
            {
                SetSelectionModeEnabled(false);

                // Refresh bindings for all pinned controls
                Refresh();
            }
            else if (b && CachedGameObject.activeInHierarchy)
            {
                // If the panel is visible, and this tab is active (selected), refresh all the data bindings
                Refresh();
            }

            if (_optionCanvas != null)
            {
                _optionCanvas.enabled = b;
            }
        }

        public void SetSelectionModeEnabled(bool isEnabled)
        {
            if (_selectionModeEnabled == isEnabled)
            {
                return;
            }

            _selectionModeEnabled = isEnabled;

            PinButton.isOn = isEnabled;
            PinPromptText.SetActive(isEnabled);
            PinPromptSpacer.SetActive(isEnabled);

            foreach (var kv in _options)
            {
                kv.Value.SelectionModeEnabled = isEnabled;

                // Set IsSelected if entering selection mode.
                if (isEnabled)
                {
                    kv.Value.IsSelected = Service.PinnedUI.HasPinned(kv.Key);
                }
            }

            foreach (var cat in _categories)
            {
                cat.CategoryGroup.SelectionModeEnabled = isEnabled;
            }

            foreach (var card in cards) card.SetSelectionMode(isEnabled);
            RefreshCategorySelection();

            // Return if entering selection mode
            if (isEnabled)
            {
                return;
            }
        }

        private void Refresh()
        {
            for (var i = 0; i < _options.Count; i++)
            {
                _controls[i].Refresh();
                _controls[i].SelectionModeEnabled = _selectionModeEnabled;
                _controls[i].IsSelected = Service.PinnedUI.HasPinned(_controls[i].Option);
            }
        }

        private void CommitPinnedOptions()
        {
            foreach (var kv in _options)
            {
                var control = kv.Value;

                if (control.IsSelected && !Service.PinnedUI.HasPinned(kv.Key))
                {
                    Service.PinnedUI.Pin(kv.Key);
                }
                else if (!control.IsSelected && Service.PinnedUI.HasPinned(kv.Key))
                {
                    Service.PinnedUI.Unpin(kv.Key);
                }
            }
        }

        private bool _isTogglingCategory;

        private void RefreshCategorySelection()
        {
            _isTogglingCategory = true;

            foreach (var cat in _categories)
            {
                var allSelected = true;

                for (var i = 0; i < cat.Options.Count; i++)
                {
                    if (!cat.Options[i].IsSelected)
                    {
                        allSelected = false;
                        break;
                    }
                }

                cat.CategoryGroup.IsSelected = allSelected;
            }

            _isTogglingCategory = false;
        }

        private void OnOptionSelectionToggle(bool selected)
        {
            if (!_isTogglingCategory)
            {
                RefreshCategorySelection();
                CommitPinnedOptions();
            }
        }

        /// <summary>
        /// When a category mode selection is changed.
        /// </summary>
        /// <param name="category"></param>
        /// <param name="selected"></param>
        private void OnCategorySelectionToggle(CategoryInstance category, bool selected)
        {
            _isTogglingCategory = true;

            for (var i = 0; i < category.Options.Count; i++)
            {
                category.Options[i].IsSelected = selected;
            }

            _isTogglingCategory = false;

            CommitPinnedOptions();
        }

        #region Initialisation

        protected void Populate()
        {
            if(population!=null)StopCoroutine(population);
            Clear();pendingPopulation=false;IsBuilding=true;
            if(ResultCount!=null)ResultCount.text="Loading…";NoOptionsNotice.SetActive(false);
            population=StartCoroutine(PopulateRoutine());
        }
        private IEnumerator PopulateRoutine()
        {
            try {
            slicePopulation=Service.Options.Options.Count>32;
            var sortedOptions = new Dictionary<string, List<OptionDefinition>>();

            foreach (var option in Service.Options.Options)
            {
                if (!OptionControlFactory.CanCreateControl(option))
                {
                    if (option.IsProperty)
                    {
                        Debug.LogError("[DreamyDebugger.OptionsTab] Unsupported property type: {0} (on property {1})".Fmt(option.Property.PropertyType, option.Property));
                    }
                    else
                    {
                        Debug.LogError("[DreamyDebugger.OptionsTab] Unsupported method signature: {0}".Fmt(option.Name));
                    }
                    continue;
                }

                // Find a properly list for that category, or create a new one
                List<OptionDefinition> memberList;

                if (!sortedOptions.TryGetValue(option.Category, out memberList))
                {
                    memberList = new List<OptionDefinition>();
                    sortedOptions.Add(option.Category, memberList);
                }

                memberList.Add(option);
            }

            var hasCreated = false;

            foreach (var kv in sortedOptions.OrderBy(p => p.Key == "Debugger" ? 1 : 0).ThenBy(p => p.Key))
            {
                if (kv.Value.Count == 0)
                {
                    continue;
                }

                hasCreated = true;
                yield return CreateCategory(kv.Key, kv.Value);
            }

            if (hasCreated)
            {
                NoOptionsNotice.SetActive(false);
            }
            
            if (CategoryFilter != null) {
                CategoryFilter.ClearOptions();
                CategoryFilter.AddOptions(new[]{"All categories"}.Concat(_categories.Select(c=>c.Name)).ToList());
                var index = CategoryFilter.options.FindIndex(o=>o.text == categoryFilter);
                CategoryFilter.SetValueWithoutNotify(Mathf.Max(0,index));
                if (index < 0) categoryFilter = "";
            }
            RefreshCategorySelection();IsBuilding=false;ApplyFilters();
            } finally {IsBuilding=false;}
        }

        private IEnumerator CreateCategory(string title, List<OptionDefinition> options)
        {
            options.Sort((d1, d2) => d1.SortPriority.CompareTo(d2.SortPriority));

            var groupInstance = ObjectFactory.Instantiate(CategoryGroupPrefab);
            var categoryInstance = new CategoryInstance(groupInstance);

            categoryInstance.Name = title;
            _categories.Add(categoryInstance);
            if (groupInstance.CollapseButton != null) groupInstance.CollapseButton.onClick.AddListener(()=>ToggleCategory(title));
            var taskCards = new Dictionary<string,OptionCard>(StringComparer.Ordinal);
            var validGroups = options.Where(o=>o.Card!=null).GroupBy(o=>o.Card.Id).Where(g=>{
                var first=g.First().Card;
                var roles=g.Select(o=>o.Card.Role).ToArray();
                return g.All(o=>o.Card.Kind==first.Kind && o.Card.Title==first.Title) && roles.Distinct().Count()==roles.Length &&
                    (first.Kind==Dreamy.Debugger.Options.CheatCardKind.Resource ? roles.Length==3 && roles.Contains(Dreamy.Debugger.Options.CheatCardRole.Balance) && roles.Contains(Dreamy.Debugger.Options.CheatCardRole.Amount) && roles.Contains(Dreamy.Debugger.Options.CheatCardRole.Action) : roles.Length==2 && roles.Contains(Dreamy.Debugger.Options.CheatCardRole.Owned) && roles.Contains(Dreamy.Debugger.Options.CheatCardRole.Action));
            }).Select(g=>g.Key).ToHashSet();

            groupInstance.CachedTransform.SetParent(ContentContainer, false);
            groupInstance.Header.text = title=="Debugger"?"Debugger tools":title;
            groupInstance.SelectionModeEnabled = _selectionModeEnabled;

            categoryInstance.CategoryGroup.SelectionToggle.onValueChanged.AddListener(
                b => OnCategorySelectionToggle(categoryInstance, b));

            var budget=Stopwatch.StartNew();
            foreach (var option in options.OrderBy(o=>o.Card==null?9:(int)o.Card.Role))
            {
                var control = OptionControlFactory.CreateControl(option, title);

                if (control == null)
                {
                    Debug.LogError("[DreamyDebugger.OptionsTab] Failed to create option control for {0}".Fmt(option.Name));
                    continue;
                }

                categoryInstance.Options.Add(control);
                control.CachedTransform.SetParent(groupInstance.Container, false);
                var root = control.gameObject;
                if (TaskCardPrefab != null && option.Card != null && validGroups.Contains(option.Card.Id)) {
                    if (!taskCards.TryGetValue(option.Card.Id,out var card)) {
                        card = Instantiate(TaskCardPrefab,groupInstance.Container,false);card.Configure(option.Card);
                        taskCards.Add(option.Card.Id,card);cards.Add(card);
                    }
                    card.Attach(control);root=card.gameObject;
                }
                roots.Add(control,root);
                if(!shownRoots.ContainsKey(root)){shownRoots.Add(root,false);categoryInstance.Roots.Add(root);}
                searchIndex.Add(control,option.Name+" "+option.Category+" "+option.StableId+" "+option.Card?.Title);
                control.IsSelected = Service.PinnedUI.HasPinned(option);
                control.SelectionModeEnabled = _selectionModeEnabled;
                var compact=option.IsMethod || option.Property!=null && (option.Property.PropertyType==typeof(bool) || option.Property.PropertyType.IsEnum);
                var layout=control.GetComponent<LayoutElement>();if(layout==null)layout=control.gameObject.AddComponent<LayoutElement>();
                layout.minWidth=compact?144:240;layout.preferredWidth=compact?240:360;layout.flexibleWidth=0;layout.layoutPriority=10;
                if(root!=control.gameObject){layout.minWidth=0;layout.preferredWidth=-1;layout.flexibleWidth=1;layout.preferredHeight=option.Card.Role==Dreamy.Debugger.Options.CheatCardRole.Amount?68:option.Card.Role==Dreamy.Debugger.Options.CheatCardRole.Balance?60:48;}
                control.SelectionModeToggle.onValueChanged.AddListener(OnOptionSelectionToggle);

                _options.Add(option, control);
                _controls.Add(control);
                if(slicePopulation && budget.Elapsed.TotalMilliseconds>=4){
                    ApplyFilters();if(ResultCount!=null)ResultCount.text="Loading "+_controls.Count+" / "+Service.Options.Options.Count;
                    yield return null;budget.Restart();
                }
            }
        }

        void Clear()
        {
            foreach (var categoryInstance in _categories)
            {
                categoryInstance.CategoryGroup.gameObject.SetActive(false);
                Destroy(categoryInstance.CategoryGroup.gameObject);
            }

            cards.Clear();roots.Clear();shownRoots.Clear();searchIndex.Clear();
            _categories.Clear();
            _controls.Clear();
            _options.Clear();
        }

        #endregion
    }
}
